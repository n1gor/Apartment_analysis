from django.apps import AppConfig


class PredictConfig(AppConfig):
    name = 'predict'
